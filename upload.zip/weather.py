import os, json, requests, twitter
from requests_oauthlib import OAuth1Session

def weather_api(event, context):
    CK = os.environ["CONSUMER_KEY"]
    CS = os.environ["CONSUMER_SECRET"]
    AT = os.environ["ACCESS_TOKEN"]
    ATS = os.environ["ACCESS_TOKEN_SECRET"]
    twitter = OAuth1Session(CK, CS, AT, ATS)

    KEY = os.environ["WEATHER_API_KEY"]
    id = 1863967 # 福岡市
    api = "http://api.openweathermap.org/data/2.5/weather?id={id}&APPID={key}"

    url = api.format(id = id, key = KEY)
    res = requests.get(url)
    data = json.loads(res.text)

    res_weather = data["weather"][0]["main"]
